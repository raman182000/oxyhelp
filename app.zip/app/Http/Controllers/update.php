<?php

namespace App\Http\Controllers;

use Todo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class update extends Controller
{
    function update(Todo $todo)
    {
        echo ('<pre>');
        print_r("jnfm");
    }
}
